/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <rosasofiamessina@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/21 15:42:07 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/21 15:42:35 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h> //per write

void	ft_print_comb2(void)
{
	int	prima;
	int	seconda;

	prima = 48;
	while (prima <= 57)
	{
		seconda = 48;
		while (seconda <= 57)
		{
			write (1, &prima, 1);
			write (1, &seconda, 1);
			if (!(prima == 57 && seconda == 57))
			write (1, ", ", 2);
			seconda ++;
		}
		prima ++;
	}
}


int	main(void)
{
	ft_print_comb2();
	write (1, "\n\t", 2);
	return (0);
}

