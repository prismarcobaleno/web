/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_is_negative.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <rosasofiamessina@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/18 11:25:57 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/18 11:26:26 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h>

void	ft_is_negative(int n)
{
	char	segno;

	segno = 'P';
	if (n < 0)
	{
		segno = 'N';
	}
	write (1, &segno, 1);
}

/*
int	main(void)
{
	ft_is_negative(1112);
	ft_is_negative(-456);
	ft_is_negative(0);
	return (0);
}
*/
