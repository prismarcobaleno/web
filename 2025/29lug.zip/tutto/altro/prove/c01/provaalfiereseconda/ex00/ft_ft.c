/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ft.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/21 17:15:38 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/21 17:15:43 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_ft(int *nbr)
{
	*nbr = 42;
}

/* void	cambia_numero(int *variabile, int valore)
{
	*variabile = valore;
}

int	main(void)
{
	int	num;
	int	*freccia;
	int	val; // Questo è un bonus

	num = 3;
	freccia = &num;
	printf("\tPrima all' indirizzo %p c'era il valore %d.\n", freccia, num);
	printf("\tOra clicca invio per chiamare la funzione...\n ft_ft();");
	scanf("...");
	ft_ft(freccia);
	printf("\tOra dentro %p c'è il valore %d.\n", freccia, num);
	
	// Ecco il bonus
	printf("\tOra decidi tu il valore!\n num = ");
	scanf("%d", &val);
	cambia_numero(freccia, val);
	printf("\tOra dentro %p c'è il valore %d.\n", freccia, num);
}
*/
