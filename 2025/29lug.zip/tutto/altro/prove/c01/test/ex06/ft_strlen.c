/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlen.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/23 16:21:25 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/23 16:21:30 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h>

int	ft_strlen(char *str)
{
	int	i;
	
	i = 0;
	while (str[i])
	{
		i += 1;
	}
	return(i);
}

int	main(void)
{
	char parola[] = "123456  345fgsdgGHW@7a";

	printf("\x1b[32m"); //verde
	printf("\tlunghezza:\t%d\n\a", ft_strlen(parola));
	printf("\x1b[0m"); //deverdificazione
	return(0);
}



