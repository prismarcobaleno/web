/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/25 14:55:23 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/25 14:55:25 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <string.h>

char	*ft_strncpy(char *dest, char *src, unsigned int n)
{
	int	i;

	i = 0;
	while (src[i] != '\0' && i < n)
	{
		dest[i] = src[i];
		i++;
	}
	while (i < n)
	{
		dest[i] = '\0';
		i++;
	}
	return (dest);
}

/*int	main(void)
{
	char	errore[] = "BUONDIiiiiiii";
	char	parola[] = "buonanotte";
	unsigned int	i = 309;
	
	printf("\x1b[32m"); // verde
	printf("\tLa mia parola era %s,", errore);
	printf("\n\t Adesso è \t%s ", ft_strncpy(errore, parola, i));
	printf("\n\t Doveva essere \t%s", strncpy(errore, parola, i));
	printf("\n\x1b[0m"); // toglie il colore
}*/
