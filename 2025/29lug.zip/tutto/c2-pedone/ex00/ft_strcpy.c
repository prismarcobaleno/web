/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcpy.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/24 16:09:39 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/24 16:09:42 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h> //per printf e scanf
#include <string.h>

char	*ft_strcpy(char *dest, char *src)
{
	int	i;

	i = 0;
	while (src[i] != '\0')
	{
		dest[i] = src[i];
		i++;
	}
	dest[i] = '\0';
	return (dest);
}

/*int	main(void)
{
	char	errore[] = "BUONGIORNO";
	char	parola[999999];
	
	
	printf("\x1b[32m"); // verde
	
	printf("\tLa mia parola era %s,", errore);
	printf("\n\tMa se me ne dici una nuova la cambio! (non troppo lunga)\n");
	scanf("%s", parola);
	printf("\t Adesso è \t%s ", ft_strcpy(errore, parola));
	printf("\n\t Doveva essere \t%s", strcpy(errore, parola));
	
	printf("\n\x1b[0m"); // toglie il colore
}*/
