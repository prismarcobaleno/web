/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_lowercase.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/25 16:49:52 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/25 16:49:57 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_lowercase(char *str)
{
	int	b;
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (!(str[i] >= 'a' && str[i] <= 'z'))
			return (0);
		i++;
	}
	return (1);
}

/*int	main(int argc, char *argv[])
{
	int	i;

	i = 1;
	printf("scrivo 1 se le stringhe che mi dai sono tutte minuscole.\n");
	while (i <= argc - 1)
	{
		printf("Argomento%d: %d\n", i, ft_str_is_lowercase(argv[i]));
		i++;
	}
	return (0);
}*/
