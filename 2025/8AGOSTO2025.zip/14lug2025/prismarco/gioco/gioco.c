//librerie varie
#include <unistd.h> // ... inutile in realtà
#include <stdio.h> // per le funzioni printf e scanf
#include <stdlib.h> // per exit

//ora iniziano le funzioni che chiamerò nel programma principale (main)(riga 51)
void stamparole(char *argv[])
{

	int i = 0;
	// tutte queste i nelle funzioni sono diverse, hanno solo lo stesso nome
	while (argv[i]) // mentre esiste l' i-esima parola degli argomenti
		{
			printf("\t\t\x1b[32mPar\x1b[35mametro %i: %s\n", i, argv[i]); // colore di par :3
			i++; // aumenta di 1 (prossimo parametro)
		}
	printf("\n"); // accapo
}

int leggiscrivi (long long int i)
{
	char eventuali; // eventuali caratteri non numerici vanno qua
	
	// dentro printf, %d significa numero (int). %c significa carattere (char)
	// \t tabulazione
	// \n accapo
	if(scanf("%lli%c", &i, &eventuali) != 2 || eventuali != '\n') 
	{
		printf("\tUhm solo numeri per favore. Ho paura che...\n\tEccì! Eccì! Le mie allergie!! Addio!\n");
		
		printf("\x1b[0m");
		exit(1);
		}
	else if (i == 0)
	{	
		printf("\tHai scritto 0! O forse era un numero troppo piccolo per me?...\n");
		return (1); // se scrivi roba troppo grossa fa overflow
	}
	else if (i == -1)
	{
		printf("\tHai scritto -1! O forse era un numero troppo grosso per me?...\n");
		return (1);
	}
	else
	{
		printf("\tHai scritto %lli! \n", i);
		return (0); // "%lli" stampa long long int
	}
} 

//programma inizia da qui!!
int	main(int argc, char *argv[])
{
	int parole = argc - 1; // numero di parole che dai all'avvio 

	printf("\x1b[35m"); //colore 35
	printf("\tCiao io amo i numeri! All'avvio mi hai detto %d \x1b[32mpar\x1b[35mametri extra:\n", parole); 

	stamparole(argv); // stampa parole.
	
	printf("\tOra dimmi un numero e io lo ripeto. In rosa.\n\t(Non premere le frecce o altri tasti!!!\n\t(Importante(Ho delle allergie(Mortali))))\n"); 
	
	long long int i; //molto lungo
	i = 1;
	while (1)
	{
		i = leggiscrivi(i); 
	}
	printf("\x1b[0m"); // toglie il colore
	return (0); // tutto a posto :3!
}


