#include <stdio.h>
#include <stdlib.h>

int main() {
    FILE *foglio = fopen("foglio.txt", "r+");

    if (!foglio) {
        fprintf(stderr, "Apertura del file fallita!\n");
        return (404);
    }
    char nome[999999];
   
	fscanf(foglio, "%s\n", nome);
	fprintf(foglio, "Ciao, %s!\n", nome);
	
    if (feof(foglio)) {
        printf("I saluti sono terminati!\n");
    }
    return (0);
}
