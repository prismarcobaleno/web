/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_program_name.c                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 13:14:15 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/06 13:14:17 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	scrivi(char c)
{
	write(1, &c, 1);
}

int	main(int carg, char *varg[])
{
	int	i;

	i = 0;
	if (carg > 0)
	{	while (varg[0][i])
		{
			scrivi(varg[0][i]);
			i++;
		}
	}
	scrivi('\n');
	return (0);
}
