/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_rev_params                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 13:17:15 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/06 13:17:19 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h> //scrivi

void	stampa(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		write(1, &str[b], 1);
		b += 1;
	}
}

int	main(int carg, char *varg[])
{
	int	i;

	i = carg;
	while (i > 1)
	{
		stampa(varg[i-1]);
		stampa("\n");
		i--;
	}
	return (0);
}
