
git ls-files -i --others --exclude-standard

