/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/18 13:26:26 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/18 13:26:29 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h> //per write

void	ft_print_comb(void)
{
	char	prima;
	char	seconda;
	char	terza;

	prima = '0';
	while (prima <= '7')
	{
		seconda = prima + 1;
		while (seconda <= '8')
		{
			terza = seconda + 1;
			while (terza <= '9')
			{
				write (1, &prima, 1);
				write (1, &seconda, 1);
				write (1, &terza, 1);
				if (!(prima == '7' && seconda == '8' && terza == '9'))
					write (1, ", ", 2);
				terza ++;
			}
			seconda ++;
		}
		prima ++;
	}
}

/*
int	main(void)
{
	ft_print_comb();
	return (0);
}
*/
