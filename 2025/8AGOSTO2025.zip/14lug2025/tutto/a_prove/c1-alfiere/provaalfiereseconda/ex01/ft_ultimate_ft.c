/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_ft.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/22 12:11:40 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/22 12:11:45 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_ultimate_ft(int *********nbr)
{
	*********nbr = 42;
}

/*
int	main(void)
{
	int	num;
	int	*freccia1;
	int	**freccia2;
	int	***freccia3;
	int	****freccia4;
	int	*****freccia5;
	int	******freccia6;
	int	*******freccia7;
	int	********freccia8;
	int	*********freccia9;

	num = 3;
	freccia1 = &num;
	freccia2 = &freccia1;
	freccia3 = &freccia2;
	freccia4 = &freccia3;
	freccia5 = &freccia4;
	freccia6 = &freccia5;
	freccia7 = &freccia6;
	freccia8 = &freccia7;
	freccia9 = &freccia8;

	printf("\t\x1b[32m Prima all'indirizzo %p c'era %d.\n", freccia9, num);
	printf("\t Ora clicca invio per chiamare la funzione...\n");
	
	printf("  \x1b[42m\x1b[30mft_ultimate_ft();\x1b[0m");
	scanf("..."); // non stampa nulla, aspetta solo invio.
	
	ft_ultimate_ft(freccia9);
	printf("\t\x1b[32m Ora dentro %p c'è il valore %d.\n", freccia9, num);
	printf("\x1b[0m"); // toglie il colore.
}
*/
