/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlowcase.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/31 12:36:36 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/31 12:36:39 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	se_maiuscola(char s)
{
	int	i;

	i = 0;
	if (!(s >= 'A' && s <= 'Z'))
		return (0);
	else
		return (1);
}

char	*ft_strlowcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (se_maiuscola(str[i]) == 1)
			str[i] = str[i] + 32;
		i++;
	}
	return (str);
}

int	main(void)
{
	char	parola[] = "BUONANotteeeeeeeeee";
	//unsigned int	i = 10;
	
	printf("\x1b[32m"); // verde
	printf("\tLa mia parola era \t%s,", parola);
	printf("\n\t Adesso è \t\t%s ", ft_strlowcase( parola));
	printf("\n\t Doveva essere minuscolizzata!");
	printf("\n\x1b[0m"); // toglie il colore
}

