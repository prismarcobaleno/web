/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcmp.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/28 11:06:30 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/28 11:06:35 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>
#include <string.h>

int	ft_strcmp(char *s1, char *s2)
{
	int	i;
	int	conta;

	i = 0;
	conta = 0;
	while (conta == 0)
	{
		if (s1[i] > s2[i])
		{
			conta = s1[i] - s2[i];
		}
		else if (s1[i] < s2[i])
		{
			conta = -(s2[i] - s1[i]);
		}
		if (s1[i] == '\0')
		{
			return (conta);
		}
		i++;
	}
	return (conta);
}


int	main(int argc, char *argv[])
{
	printf("\t{%s}, {%s}\n", argv[1], argv[2]);
	if (argc > 1)
	{
		printf("\tmia:\t%d\n", ft_strcmp(argv[1], argv[2]));
		printf("\tvera:\t%d\n", strcmp(argv[1], argv[2]));
	}
	else
		printf("\tDammi 2 argomenti!\n");
}

