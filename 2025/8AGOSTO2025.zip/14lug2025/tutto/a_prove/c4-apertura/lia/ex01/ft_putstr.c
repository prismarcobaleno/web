/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/22 17:23:04 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/22 17:23:07 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_putstr(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		write(1, &str[b], 1);
		b += 1;
	}
}

int	main(void)
{
	char parola[] = "hello ciao hola";
	
	ft_putstr(parola);
	write(1, "\n", 1);
	return(0);
}
