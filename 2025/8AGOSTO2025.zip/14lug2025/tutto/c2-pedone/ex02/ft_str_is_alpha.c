/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/25 15:24:10 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/25 15:24:14 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

/*int	ft_str_is_alpha(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		if (str[b] < 'A' || str[b] > 'z')
			return (0);
		else if (str[b] > 'Z' && str[b] < 'a')
			return (0);
		b++;
	}
	return (1);
}*/
int	ft_str_is_alpha(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if ((str[i] < 'a' || str[i] > 'z') && (str[i] < 'A' || str[i] > 'Z'))
		{
			return (0);
		}
		i++;
	}
	return (1);
}
/*int	main(int argc, char *argv[])
{
	int	i;
	
	i = 1;
	printf("scrivo 1 se le stringhe che mi dai sono puramente alfabetiche.\n");
	while(i <= argc-1)
	{
		printf("%d\n", ft_str_is_alpha(argv[i]));
		i++;
	}
	return(0);
}*/
