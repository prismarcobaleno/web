#!/bin/bash
cd ..
git ls-files -o | cat -e
