/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_alphabet.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <rosasofiamessina@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/16 18:16:56 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/16 18:17:33 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>

void	ft_print_alphabet(void)
{
	char	lettera;

	lettera = 97;
	while (lettera < 123)
	{
		write (1, &lettera, 1);
		lettera += 1;
	}
}

/*int	main(void)
{
	ft_print_alphabet();
	return (0);
}*/
