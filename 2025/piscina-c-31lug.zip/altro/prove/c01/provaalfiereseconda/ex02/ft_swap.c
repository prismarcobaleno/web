/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_swap.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/22 15:00:56 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/22 15:00:59 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_swap(int *a, int *b)
{
	int	muovi;

	muovi = *a;
	*a = *b;
	*b = muovi;
}

/*
int main(void)
{
	int a;
	int b;

	printf("\t\x1b[32m Dammi un intero:\n ");
	scanf("%d", &a);

	printf("\t Ora dammi un altro intero:\n ");
	scanf("%d", &b);

	ft_swap(&a, &b);
	printf("\t Te li ho scambiati! Ora sono %d e %d.\n", a, b);

	printf("\x1b[0m"); // toglie il colore verde	
}
*/
