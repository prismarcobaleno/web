/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_alpha.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/25 15:24:10 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/25 15:24:14 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_alpha(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		if (!(str[b] > 65 && str[b] < 122))
			return (0);
		else if (str[b] > 90 && str[b] < 97)
			return (0);
		b++;
	}
	return (1);
}

/*int	main(int argc, char *argv[])
{
	int	i;
	
	i = 1;
	printf("scrivo 1 se le stringhe che mi dai sono puramente alfabetiche.\n");
	while(i <= argc-1)
	{
		printf("%d\n", ft_str_is_alpha(argv[i]));
		i++;
	}
	return(0);
}*/
