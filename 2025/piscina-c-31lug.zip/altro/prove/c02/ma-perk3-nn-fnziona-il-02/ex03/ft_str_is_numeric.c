/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_str_is_numeric.c                                :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/25 16:41:45 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/25 16:41:48 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	ft_str_is_numeric(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		if (str[b] < '0' || str[b] > '9')
			return (0);
		b++;
	}
	return (1);
}

/*int	main(int argc, char *argv[])
{
	int	i;

	i = 1;
	printf("scrivo 1 se le stringhe che mi dai sono puramente numeriche.\n");
	while (i <= argc - 1)
	{
		printf("Argomento%d: %d\n", i, ft_str_is_numeric(argv[i]));
		i++;
	}
	return (0);
}*/
