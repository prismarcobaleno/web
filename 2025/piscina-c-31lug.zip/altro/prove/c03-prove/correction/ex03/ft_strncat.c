/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strncat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/29 17:23:48 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/29 17:23:50 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <string.h>
#include <stdio.h>

int	lunghezza(char *str)
{
	int	l;

	l = 0;
	while (str[l])
	{
		l += 1;
	}
	return (l);
}

char	*ft_strncat(char *dest, char *src, unsigned int nb)
{
	unsigned int	lun_dest;
	unsigned int	i;

	lun_dest = lunghezza(dest);
	i = 0;
	while (i < nb && src[i] != '\0')
	{
		dest[lun_dest + i] = src[i];
		i++;
	}
	dest[lun_dest + i] = '\0';
	return (dest);
}

int	main(int argc, char *argv[])
{	
	int	num = 0; 

	printf("\x1b[32m"); //verde
	printf("\t{%s}, {%s}\n", argv[1], argv[2]);
	if (argc > 2)
	{	
		printf("\tDammi un numero:\n");
		scanf("%d", &num);
		printf("\tmia:\t%s\n", ft_strncat(argv[1], argv[2], num));
		printf("\tvera:\t%s\n", strncat(argv[1], argv[2], num));
	}
	else
		printf("\tDammi 2 argomenti!\n");
	printf("\x1b[0m"); //deverdificazione
}
