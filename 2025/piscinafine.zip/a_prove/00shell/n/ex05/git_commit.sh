#!/bin/bash

echo "Ultimi 5 commit ID:"
git log --oneline -5 --pretty=format:"%H"