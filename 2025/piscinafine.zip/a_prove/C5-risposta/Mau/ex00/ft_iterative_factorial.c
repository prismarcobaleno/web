/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/01 14:02:11 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/01 14:02:13 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h> 

int	ft_iterative_factorial(int nb)
{
	int	ft;
	int	i;

	i = 1;
	ft = 1;
	if (nb == 0)
		return (1);
	if (nb < 0)
		return (0);
	while (i++ < nb)
	{
		ft *= i;
	}
	return (ft);
}

int	main(void)
{
	int n = 0;
	while (1)
	{
		printf("Numero: ");
		scanf("%d", &n);
		printf("%d\n", ft_iterative_factorial(n));
	}
}
