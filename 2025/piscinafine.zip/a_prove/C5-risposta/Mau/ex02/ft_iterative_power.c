/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_iterative_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/05 14:14:23 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/05 14:14:24 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h> 

int	ft_iterative_power(int nb, int power)
{
	int	i;
	int	ris;

	ris = 1;
	i = 0;
	if (nb == 0)
		return (1);
	if (power < 0)
		return (0);
	while (i++ < power)
	{
		ris = ris * nb;
	}
	return (ris);
}

int	main(void)
{
	int base = 0;
	int potenza = 0;

	while (1)
	{
		printf("Base: ");
		scanf("%d", &base);
		printf("Potenza: ");
		scanf("%d", &potenza);
		printf("%d\n", ft_iterative_power(base, potenza));
	}
}
