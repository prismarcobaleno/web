/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_power.c                               :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/05 15:28:38 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/05 15:28:40 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h> 

int	ft_recursive_power(int nb, int power)
{
	int	i;
	int	ris;

	ris = 1;
	i = 0;
	if (nb == 0)
	{
		return (ris);
	}
	if (power < 0)
	{
		return (0);
	}
	if (power-- > 0)
	{
		ris = ris * nb;
		ris *= ft_recursive_power(ris, power);
	}
	return (ris);
}

int	main(void)
{
	int base = 0;
	int potenza = 0;

	while (1)
	{
		printf("Base: ");
		scanf("%d", &base);
		printf("Potenza: ");
		scanf("%d", &potenza);
		printf("%d\n", ft_recursive_power(base, potenza));
	}
}
