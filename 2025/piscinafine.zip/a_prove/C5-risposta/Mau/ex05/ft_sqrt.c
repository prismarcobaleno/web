/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sqrt.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 13:05:28 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/06 13:05:30 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include<stdio.h>

int	ft_sqrt(int nb)
{
	int	i;

	if (nb <= 0)
	{
		return (0);
	}
	i = 0;
	while (i <= nb && i <= 46341)
	{
		if (i * i == nb)
		{
			return (i);
		}
		i++;
	}
	return (0);
}
int	main(void)
{
	int n = 0;
	while (1)
	{
		printf("Numero: ");
		scanf("%d", &n);
		printf("%d\n", ft_sqrt(n));
	}
}
