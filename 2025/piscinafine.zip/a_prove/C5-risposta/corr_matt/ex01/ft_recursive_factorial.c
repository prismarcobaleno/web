/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_recursive_factorial.c                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/04 13:59:24 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/04 13:59:27 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h> 

int	ft_recursive_factorial(int nb)
{
	long int ft = (long)nb;

	if (ft == 0)
		return(1);
	if (ft < 0)
		return(0);
	if (ft > 0)
	{
		ft = ft * ft_recursive_factorial(ft - 1);
	}
	return(ft);
}

/*int	main(void)
{
	int n = 0;
	while (1)
	{
		printf("Numero: ");
		scanf("%d", &n);
		printf("%d\n", ft_recursive_factorial(n));
	}
}*/
