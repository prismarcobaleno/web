/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_fibonacci.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/05 15:58:15 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/05 15:58:19 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h> 

int	ft_sbagliata(int nb)
{
	int	i;
	int	fi;
	
	i = 1;
	fi = 1;
	if (nb < 0)
	{
		fi = -1;
		return (fi);
	}
	if (nb == 0)
	{
		fi = 0;
		return (fi);
	}
	else
	{
		fi =  ft_sbagliata(nb - 2) + ft_sbagliata(nb - 1);
	}
	return (fi);
}

int	ft_fibonacci(int nb)
{
	if (nb < 0)
	{
		return (-1);
	}
	else
		return (-ft_sbagliata(nb));
}

/*int	main(void)
{
	int n = 0;
	while (1)
	{
		printf("Numero: ");
		scanf("%d", &n);
		printf("%d\n", ft_fibonacci(n));
	}
}*/
