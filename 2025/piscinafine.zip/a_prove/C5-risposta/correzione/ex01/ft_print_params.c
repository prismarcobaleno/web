/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_params.c                                  :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/08/06 13:17:15 by rosmessi          #+#    #+#             */
/*   Updated: 2025/08/06 13:17:18 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h> //scrivi

void	stampa(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		write(1, &str[b], 1);
		b += 1;
	}
}

int	main(int carg, char *varg[])
{
	int	i;

	i = 1;
	while (i < carg)
	{
		stampa(varg[i]);
		stampa("\n");
		i++;
	}
	return (0);
}
