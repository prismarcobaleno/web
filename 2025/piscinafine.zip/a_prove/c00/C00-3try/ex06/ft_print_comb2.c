/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_comb2.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <rosasofiamessina@gmail.com>      +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/21 15:42:07 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/21 15:42:35 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <unistd.h> //per write

void	stampe(int num)
{
	int	deci;
	int	uni;

	deci = (num / 10) + 48;
	uni = (num % 10) + 48;
	write (1, &deci, 1);
	write (1, &uni, 1);
}

// scrive un numero di 2 cifre con write. 
// se le passi una cifra aggiunge 0 prima.

void	ft_print_comb2(void)
{
	int	prima;
	int	seconda;

	prima = 0;
	seconda = 1;
	while (prima <= 99)
	{
		while (seconda <= 99)
		{
			stampe(prima);
			write (1, " ", 1);
			stampe(seconda);
			if (!(prima == 99 && seconda == 99))
				write (1, ", ", 2);
			seconda ++;
		}
		seconda = 0;
		prima ++;
	}
	prima = 0;
	seconda = 0;
}

//aumenta da 00 a 99.


int	main(void)
{
	ft_print_comb2();
	write (1, "\n", 2);
	return (0);
}

