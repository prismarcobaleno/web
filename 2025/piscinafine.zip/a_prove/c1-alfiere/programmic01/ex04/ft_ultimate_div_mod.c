/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ultimate_div_mod.c                              :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/22 14:20:09 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/22 14:20:13 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include <stdio.h>

void	ft_div_mod(int *a, int *b)
{
	int	divid;
	int	divis;

	divid = *a;
	divis = *b;
	if (divis != 0)
	{
		*a = divid / divis;
		*b = divid % divis;
	}
}

/*
int	main(void)
{
	int	*a_freccia;
	int	*b_freccia;
	int	a;
	int	b;
	
	a_freccia = &a;
	b_freccia = &b;
	a = 1234;
	b = 10;
	
	printf("%d / %d ", *a_freccia, *b_freccia);
	ft_div_mod(a_freccia, b_freccia);
	printf("= %d r %d \n", *a_freccia, *b_freccia);
	printf("\x1b[0m"); // toglie il colore verde
}
*/
