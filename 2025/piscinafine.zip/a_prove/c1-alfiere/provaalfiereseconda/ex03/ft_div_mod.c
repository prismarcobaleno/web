/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_div_mod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/22 13:06:04 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/22 13:06:07 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

void	ft_div_mod(int a, int b, int *div, int *mod)
{
	if (b != 0)
	{
		*div = a / b;
		*mod = a % b;
	}
}

/*int	main(void)
{
	int	divid;
	int	divis;
	int	*quoz;
	int	*resto;
	char	cara; // per vedere che non mi dai lettere
	quoz = &divid; // assegnazioni a caso per non far arrabbiare il compilatore
	resto = &divis;
	
	printf("\t\x1b[32m Dammi un dividendo intero:\n");
	scanf("%d%c", &divid, &cara);
	if(cara != '\n')
		printf("\t\x1b[32m Aah! Terribile errore! Non riesco a dividere!\n"); 
	else
	{
		printf("\t Ora dammi un divisore intero:\n");
		scanf("%d%c", &divis, &cara);
		if (divis == 0 || cara != '\n')
			printf("\t\x1b[32m Aah! Errore! Non riesco a dividere!\n"); 
		else 
		{
			ft_div_mod(divid, divis, quoz, resto);
			printf("\t Il risultato è %d resto %d.\n", *quoz, *resto);
		}
	}
	printf("\x1b[0m"); // toglie il colore verde
}
*/
