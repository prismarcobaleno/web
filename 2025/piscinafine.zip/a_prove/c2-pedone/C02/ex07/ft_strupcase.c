/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strupcase.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/31 12:21:29 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/31 12:21:32 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <stdio.h>

int	se_minuscola(char s)
{
	int	i;

	i = 0;
	if (!(s >= 'a' && s <= 'z'))
		return (0);
	else
		return (1);
}

char	*ft_strupcase(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (se_minuscola(str[i]) == 1)
			str[i] = str[i] - 32;
		i++;
	}
	return (str);
}

/*int	main(void)
{
	char	parola[] = "buonanotteeeeeeeeee";
	unsigned int	i = 10;
	
	printf("\x1b[32m"); // verde
	printf("\tLa mia parola era \t%s,", parola);
	printf("\n\t Adesso è \t\t%s ", ft_strupcase(errore, parola, i));
	printf("\n\t Doveva essere maiuscolizzata!");
	printf("\n\x1b[0m"); // toglie il colore
}*/
