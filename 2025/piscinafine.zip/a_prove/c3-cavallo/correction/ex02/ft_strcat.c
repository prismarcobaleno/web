/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strcat.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/29 17:10:32 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/29 17:10:35 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <string.h>
#include <stdio.h>

char	*ft_strcat(char *dest, char *src)
{
	int	lun;
	int	j;

	lun = 0;
	j = 0;
	while (dest[lun] != '\0')
	{
		lun++;
	}
	while (src[j] != '\0')
	{
		dest[lun] = src[j];
		lun++;
		j++;
	}
	dest[lun] = '\0';
	return (dest);
}

int	main(int argc, char *argv[])
{
	printf("\t{%s}, {%s}\n", argv[1], argv[2]);
	if (argc > 2)
	{	
		printf("\tDammi un numero:\n");
		//scanf("%d", &num);
		printf("\tmia:\t%s\n", ft_strcat(argv[1], argv[2]));
		printf("\tvera:\t%s\n", strcat(argv[1], argv[2]));
		printf("\tGrazie e addio!\n");
	}
	//else
		//printf("\tDammi 2 argomenti!\n");
}
