/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_putnbr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: rosmessi <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/07/31 14:20:17 by rosmessi          #+#    #+#             */
/*   Updated: 2025/07/31 14:20:18 by rosmessi         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */
#include <unistd.h>
#include <stdio.h> 

void	cifra(int c);
void	ft_putnbr(int nb);

void	cifra(int c)
{
	char	s;

	s = (char)c + 48;
	write(1, &s, 1);
}

void	stampa(char *str)
{
	int	b;

	b = 0;
	while (str[b] != '\0')
	{
		write(1, &str[b], 1);
		b += 1;
	}
}

void	ft_putnbr(int nb)
{
	if (nb == -2147483648)
	{
		stampa("-2147483648");
		return ;
	}
	if (nb < 0)
	{
		write(1, "-", 1);
		ft_putnbr(-nb);
	}
	if (0 <= nb && nb <= 9)
		cifra(nb);
	if (nb > 9)
	{
		ft_putnbr(nb / 10);
		cifra(nb % 10);
	}
}

/*int	main(void)
{
	int i = 1;
	int b = 0;
	char eventuali = 0;
	
	printf("\x1b[30m"); // colore
	printf("\n\tDammi un numero e lo scrivo:\n");
	
	while (b++ < 10)
	{
		printf("\n\tNumero: ");
		scanf("%d%c", &i, &eventuali);
		ft_putnbr(i);
	}
	printf("\x1b[0m"); // colore
}*/
