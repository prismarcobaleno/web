#!/bin/bash

ls -1 | wc -l
